import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from skfda.exploratory.depth import ModifiedBandDepth
from skfda.exploratory.visualization import Boxplot
from skfda.representation.grid import FDataGrid
from fpc1_extraction import first_component_extraction

def bootstrap(system1_data, system2_data, sensor, window, features="FluidTempBin", n_sim=100):
    """
    Perform bootstrap resampling and Functional PCA analysis on two systems' data.

    Parameters:
    system1_data (pd.DataFrame): Data from System 1.
    system2_data (pd.DataFrame): Data from System 2.
    sensor (str): Name of the sensor.
    window (str): Name of the window.
    features (str, optional): Feature to be used for resampling and analysis. Defaults to "FluidTempBin".
    n_sim (int, optional): Number of resampling iterations. Defaults to 100.

    Returns:
    tuple: A tuple containing:
           - List of Functional PC 1 values for System 1.
           - List of Functional PC 1 values for System 2.
    """

    # Initialize lists to store Functional PC 1 values
    fpca_s1_list = []
    fpca_s2_list = []
    fpca_s1_list_f = []
    fpca_s2_list_f = []

    # Determine the minimum number of samples for resampling
    Resample_Value1 = system1_data[features].value_counts().min()
    Resample_Value2 = system2_data[features].value_counts().min()
    Resample_Value = min(Resample_Value1, Resample_Value2)

    # Perform bootstrap resampling
    for i in range(n_sim):
        # Randomly sample data for both systems with replacement
        Id1 = system1_data.groupby(features, group_keys=False).apply(lambda x: x.sample(Resample_Value, replace=True)).index
        Id2 = system2_data.groupby(features, group_keys=False).apply(lambda x: x.sample(Resample_Value, replace=True)).index
        Resample_data1 = system1_data.loc[Id1, :].iloc[:, :-6]
        Resample_data2 = system2_data.loc[Id2, :].iloc[:, :-6]

        # Perform Functional PCA on resampled data
        fpca_s1, fpca_s2 = first_component_extraction(Resample_data1, Resample_data2)

        fpca_s1_f = fpca_s1.data_matrix[0].flatten()
        fpca_s2_f = fpca_s2.data_matrix[0].flatten()

        # Append Functional PC 1 values to the lists
        fpca_s1_list_f.append(fpca_s1_f)
        fpca_s2_list_f.append(fpca_s2_f)

        # Store the actual FPCA results directly without adding any noise
        fpca_s1_list.append(fpca_s1.data_matrix[0])
        fpca_s2_list.append(fpca_s2.data_matrix[0])

    # Calculate upper and lower percentiles for confidence intervals directly from the empirical distribution
    upper1 = np.percentile(fpca_s1_list_f, 95, axis=0)
    lower1 = np.percentile(fpca_s1_list_f, 5, axis=0)
    x1 = np.arange(len(upper1))

    upper2 = np.percentile(fpca_s2_list_f, 95, axis=0)
    lower2 = np.percentile(fpca_s2_list_f, 5, axis=0)
    x2 = np.arange(len(upper2))

    print("Confidence Interval of 1st component")
    # Plot Functional PC 1 values and confidence intervals
    fig, axs = plt.subplots(1, 3, figsize=(18.8, 3.5))
    
    axs[0].plot(x1, np.mean(fpca_s1_list_f, axis=0), color='tab:blue', linewidth=1, label='Mean FPC1 S1')
    axs[0].fill_between(x1, lower1, upper1, color='tab:blue', alpha=0.2, label='95% Confidence Interval S1')

    axs[0].plot(x2, np.mean(fpca_s2_list_f, axis=0), color='tab:orange', linewidth=1, label='Mean FPC1 S2')
    axs[0].fill_between(x2, lower2, upper2, color='tab:orange', alpha=0.05, label='95% Confidence Interval S2')
    
    axs[0].axhline(y=0, color='black', linestyle='--', linewidth=0.5)

    # Set plot labels and title
    axs[0].set_xlabel('Time')
    axs[0].set_ylabel('Functional PC 1 Values')
    axs[0].set_title(f"System 1 versus System 2 in {sensor} {window}")
    axs[0].legend()

    # Print the number of resampling iterations
    print(f"The number of sampling is {Resample_Value}")

    # Calculate global y-limits for boxplots
    all_fpca_values = np.concatenate(fpca_s1_list + fpca_s2_list)
    y_min, y_max = np.min(all_fpca_values), np.max(all_fpca_values)

    # Boxplot(to distinguish the outliers)
    print("The boxplot of 1st Component")
    box_data1 = FDataGrid(data_matrix=fpca_s1_list, grid_points=range(fpca_s1_list[0].shape[0]))
    box1 = Boxplot(box_data1, depth_method=ModifiedBandDepth(), factor=0.1, axes=axs[1])  # You can decrease the value of factor to better detect outliers
    box1.show_full_outliers = True
    box1.plot()
    axs[1].set_ylim(y_min, y_max)

    box_data2 = FDataGrid(data_matrix=fpca_s2_list, grid_points=range(fpca_s1_list[0].shape[0]))
    box2 = Boxplot(box_data2, depth_method=ModifiedBandDepth(), factor=0.1, axes=axs[2])
    box2.show_full_outliers = True
    box2.plot()
    axs[2].set_ylim(y_min, y_max)

    axs[1].set_title('Boxplot for system 1')
    axs[2].set_title('Boxplot for system 2')
    plt.tight_layout()
    plt.show()
    return fpca_s1_list_f, fpca_s2_list_f