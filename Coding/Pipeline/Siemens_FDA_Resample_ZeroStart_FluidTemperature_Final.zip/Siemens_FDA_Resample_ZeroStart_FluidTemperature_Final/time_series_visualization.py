import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
def plot_all_time_series(df, title):
    """
    Plots all time series data from a DataFrame.

    Parameters:
    df (pd.DataFrame): A pandas DataFrame where each row represents a time series. The values in the rows are the
                       data points of the time series.
    title (str): The title for the plot.

    Returns:
    Display the chart with all the time series in one plot.
    """
    plt.figure(figsize=(6, 4))

    # Generate colors using a colormap
    num_lines = len(df)
    colors = plt.cm.Greys(np.linspace(0, 1, num_lines))

    # Plot each row with a different color
    for index, (i, row) in enumerate(df.iterrows()):
        plt.plot(row.values, label=f'Time Series {i + 1}', color=colors[index])

    plt.ylabel('Electrical signals (mV)')
    plt.xlabel('Time (s)')
    plt.title(title)
    plt.show()


def plot_all_time_series_and_mean_fpca(ax, df, title, x_new, y_new):
    """
    Plots all time series data from a DataFrame on a given axis and adds a new curve.

    Parameters:
    ax (matplotlib.axes.Axes): The axis to plot on.
    df (pd.DataFrame): A pandas DataFrame where each row represents a time series. The values in the rows are the
                       data points of the time series.
    title (str): The title for the plot.
    x_new (array-like): The x values for the mean from the fpca.
    y_new (array-like): The y values for the mean from the fpca.

    Returns:
    Displays the chart with all the time series and the new curve in one plot.
    """

    # Generate colors using a colormap
    num_lines = len(df)
    colors = plt.cm.Greys(np.linspace(0, 1, num_lines))

    # Plot each row with a different color
    for index, (i, row) in enumerate(df.iterrows()):
        ax.plot(row.values, color=colors[index])

    # Add the new curve
    ax.plot(x_new, y_new, label='Mean Function', color='red', linewidth=2)
    ax.legend()
    ax.set_ylabel('Electrical signals (mV)')
    ax.set_xlabel('Time (s)')
    ax.set_title(title)
    ax.grid(False)
