# Import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from skfda.representation.grid import FDataGrid
import skfda
from skfda.ml.regression import LinearRegression
import statsmodels.api as sm

def visualize_regression(fpca_s1, fpca_s2):
    """
    Visualize regression analysis results for two sets of functional data.

    Parameters:
    fpca_s1 (FPCA): Functional PCA analysis result for system 1.
    fpca_s2 (FPCA): Functional PCA analysis result for system 2.

    Returns:
    tuple: A tuple containing:
           - Slope of the regression line for system 1.
           - Slope of the regression line for system 2.
    """
    # Extract grid points and data values for both sets of data
    x1 = fpca_s1.grid_points[0]
    y1 = fpca_s1.data_matrix[0].flatten()
    x2 = fpca_s2.grid_points[0]
    y2 = fpca_s2.data_matrix[0].flatten()

    # Add a constant to the feature variables
    x1_with_const = sm.add_constant(x1)
    x2_with_const = sm.add_constant(x2)

    # Create and fit a linear regression model for the first set of data
    model1 = sm.OLS(y1, x1_with_const).fit()

    # Create and fit a linear regression model for the second set of data
    model2 = sm.OLS(y2, x2_with_const).fit()

    # Output detailed summary of the models
    summary1 = model1.summary()
    summary2 = model2.summary()
    slope1 = model1.params[1]
    slope2 = model2.params[1]
    print(summary1)
    print(summary2)

    # Extract predicted values from the models
    y1_pred = model1.predict(x1_with_const)
    y2_pred = model2.predict(x2_with_const)

    # Compute confidence intervals
    pred1 = model1.get_prediction(x1_with_const)
    pred_summary1 = pred1.summary_frame(alpha=0.05)  # 95% confidence interval
    ci_lower1 = pred_summary1['obs_ci_lower']
    ci_upper1 = pred_summary1['obs_ci_upper']

    pred2 = model2.get_prediction(x2_with_const)
    pred_summary2 = pred2.summary_frame(alpha=0.05)  # 95% confidence interval
    ci_lower2 = pred_summary2['obs_ci_lower']
    ci_upper2 = pred_summary2['obs_ci_upper']

    # Visualize the results
    plt.figure(figsize=(10, 6))

    # Plot results for the first set of data
    plt.scatter(x1, y1, color='blue', label='Data points 1')
    plt.plot(x1, y1_pred, color='red', linewidth=2, label='Regression line 1')
    plt.fill_between(x1, ci_lower1, ci_upper1, color='red', alpha=0.2, label='95% Confidence Interval 1')

    # Plot results for the second set of data
    plt.scatter(x2, y2, color='green', label='Data points 2')
    plt.plot(x2, y2_pred, color='orange', linewidth=2, label='Regression line 2')
    plt.fill_between(x2, ci_lower2, ci_upper2, color='orange', alpha=0.2, label='95% Confidence Interval 2')

    plt.xlabel("X")
    plt.ylabel("y")
    plt.legend()
    plt.show()
    return slope1, slope2
