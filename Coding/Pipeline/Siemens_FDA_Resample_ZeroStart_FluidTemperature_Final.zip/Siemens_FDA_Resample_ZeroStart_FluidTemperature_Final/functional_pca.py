# Import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from skfda.representation.grid import FDataGrid
from skfda.preprocessing.dim_reduction.projection import FPCA
import skfda
from time_series_visualization import plot_all_time_series_and_mean_fpca

def fpca_two_inputs(time_series_s1, time_series_s2, color_fpc1_s1=None, color_fpc2_s1=None, color_fpc1_s2=None, color_fpc2_s2=None):
    """
    Performs Functional Principal Component Analysis (FPCA) on two sets of time series data from different systems
    and plots the first principal component for both systems on the same graph.

    Parameters:
    time_series_s1 (pd.DataFrame): A pandas DataFrame representing time series data from System 1. Each row represents
                                   a time series and each column represents a time point.
    time_series_s2 (pd.DataFrame): A pandas DataFrame representing time series data from System 2. Each row represents
                                   a time series and each column represents a time point.
    color_fpc1_s1 (str, optional): Color for the first principal component of System 1.
    color_fpc2_s1 (str, optional): Color for the second principal component of System 1.
    color_fpc1_s2 (str, optional): Color for the first principal component of System 2.
    color_fpc2_s2 (str, optional): Color for the second principal component of System 2.

    Returns:
    tuple: A tuple containing two pandas DataFrames representing the functional principal component scores for System 1
           and System 2 respectively.

    Prints:
    - The explained variance ratio of the first principal component for both systems.
    - The functional principal component scores for each time series in both systems.
    - Plots the first principal component for both systems on the same graph.
    - Plots the first principal component of System 1 versus the first principal component of System 2.
    """
    # fpca_s1,fpca_s2,pc_scores_s1,pc_scores_s2 = fpca_component_and_score(time_series_s1, time_series_s2, color_fpc1_s1=None, color_fpc2_s1=None, color_fpc1_s2=None, color_fpc2_s2=None)
    # Convert the data matrix to an FDataGrid object
    fd_s1 = FDataGrid(data_matrix=time_series_s1, grid_points=time_series_s1.columns.astype(float)) # System 1
    fd_s2 = FDataGrid(data_matrix=time_series_s2, grid_points=time_series_s2.columns.astype(float)) # System 2

    # Apply Functional PCA for System 1
    fpca_s1 = FPCA(n_components=2, centering=True)
    fpca_s1.fit(fd_s1)
    fpc_and_scores_s1 = fpca_s1.transform(fd_s1)

    # Apply Functional PCA for System 2
    fpca_s2 = FPCA(n_components=2)
    fpca_s2.fit(fd_s2)
    fpc_and_scores_s2 = fpca_s2.transform(fd_s2)

    # --- Explain variance ratio ---

    # System 1
    print('S1 Explain variance PC1 (%): ', fpca_s1.explained_variance_ratio_[0] * 100)
    print('S1 Explain variance PC2 (%): ', fpca_s1.explained_variance_ratio_[1] * 100)
    # System 2
    print('S2 Explain variance PC1 (%): ', fpca_s2.explained_variance_ratio_[0] * 100)
    print('S2 Explain variance PC2 (%): ', fpca_s2.explained_variance_ratio_[1] * 100)

    # --- Eigenfunctions ---

    # Extract the principal components
    principal_components_s1 = fpca_s1.components_ # System 1
    principal_components_s2 = fpca_s2.components_ # System 2

    # --- Scores (eigenvalues) ---

    # System 1
    pc_scores_s1 = pd.DataFrame(fpc_and_scores_s1, columns=['PC1_Scores', 'PC2_Scores'],
                                index=[time_series_s1.index[i] for i in range(time_series_s1.shape[0])])
    # System 2
    pc_scores_s2 = pd.DataFrame(fpc_and_scores_s2, columns=['PC1_Scores', 'PC2_Scores'],
                                index=[time_series_s2.index[i] for i in range(time_series_s2.shape[0])])

    # Identify which time series (functional data object) contributes the most to each principal component

    # System 1
    max_contribution_index_pc1_s1 = np.argmax(np.abs(fpc_and_scores_s1[:, 0]))  # Index of the maximum absolute score in the first PC
    max_contribution_index_pc2_s1 = np.argmax(np.abs(fpc_and_scores_s1[:, 1]))  # Index of the maximum absolute score in the second PC

    print(f'The time series contributing most to PC1 is at index {max_contribution_index_pc1_s1} with TestID {time_series_s1.index[max_contribution_index_pc1_s1]}')
    print(f'The time series contributing most to PC2 is at index {max_contribution_index_pc2_s1} with TestID {time_series_s1.index[max_contribution_index_pc2_s1]}')

    # System 2
    max_contribution_index_pc1_s2 = np.argmax(np.abs(fpc_and_scores_s2[:, 0]))  # Index of the maximum absolute score in the first PC
    max_contribution_index_pc2_s2 = np.argmax(np.abs(fpc_and_scores_s2[:, 1]))  # Index of the maximum absolute score in the second PC

    print(f'The time series contributing most to PC1 is at index {max_contribution_index_pc1_s2} with TestID {time_series_s2.index[max_contribution_index_pc1_s2]}')
    print(f'The time series contributing most to PC2 is at index {max_contribution_index_pc2_s2} with TestID {time_series_s2.index[max_contribution_index_pc2_s2]}')

    # --- Plotting First Principal Component for both Systems ---

    # Extracting data for System 1
    x1_FPC1 = fpca_s1.components_[0].grid_points[0]
    y1_FPC1 = fpca_s1.components_[0].data_matrix[0].flatten()

    x1_FPC2 = fpca_s1.components_[1].grid_points[0]
    y1_FPC2 = fpca_s1.components_[1].data_matrix[0].flatten()

    y_s1_mean_function = fpca_s1.mean_.data_matrix.flatten()

    # Extracting data for System 2
    x2_FPC1 = fpca_s2.components_[0].grid_points[0]
    y2_FPC1 = fpca_s2.components_[0].data_matrix[0].flatten()

    x2_FPC2 = fpca_s2.components_[1].grid_points[0]
    y2_FPC2 = fpca_s2.components_[1].data_matrix[0].flatten()

    y_s2_mean_function = fpca_s2.mean_.data_matrix.flatten()

    # Calculate the global y-limits

    # Mean Function
    all_y_values_s1 = np.concatenate([time_series_s1.values.flatten(), y_s1_mean_function])
    all_y_values_s2 = np.concatenate([time_series_s2.values.flatten(), y_s2_mean_function])
    global_y_min = min(all_y_values_s1.min(), all_y_values_s2.min())
    global_y_max = max(all_y_values_s1.max(), all_y_values_s2.max())

    all_y_FPC_s1 = np.concatenate([y1_FPC1, y1_FPC2])
    all_y_FPC_s2 = np.concatenate([y2_FPC1, y2_FPC2])
    global_y_FPC_min = min(all_y_FPC_s1.min(), all_y_FPC_s2.min())
    global_y_FPC_max = max(all_y_FPC_s1.max(), all_y_FPC_s2.max())

    all_y_FPC1 = np.concatenate([y1_FPC1, y2_FPC1])
    global_y_FPC1_min = all_y_FPC1.min()
    global_y_FPC1_max = all_y_FPC1.max()

    # Round the y-limits to 2 decimal places
    global_y_min = np.around(global_y_min, 2)
    global_y_max = np.around(global_y_max, 2)
    global_y_FPC_min = np.around(global_y_FPC_min, 2)
    global_y_FPC_max = np.around(global_y_FPC_max, 2)
    global_y_FPC1_min = np.around(global_y_FPC1_min, 2)
    global_y_FPC1_max = np.around(global_y_FPC1_max, 2)

    # --- Plotting Principal Components ---

    fig, axs = plt.subplots(2, 2, figsize=(16, 6))

    # Plot for System 1 waveforms
    plot_all_time_series_and_mean_fpca(axs[0, 0], time_series_s1, 'System 1 waveforms', x1_FPC1, y_s1_mean_function)
    axs[0, 0].set_ylim(global_y_min, global_y_max)  # Set y-limits

    # Plot for System 2 waveforms
    plot_all_time_series_and_mean_fpca(axs[0, 1], time_series_s2, 'System 2 waveforms', x2_FPC1, y_s2_mean_function)
    axs[0, 1].set_ylim(global_y_min, global_y_max)  # Set y-limits

    # FPC's System 1
    axs[1, 0].plot(x1_FPC1, y1_FPC1, linestyle='-', label='FPC1', color=color_fpc1_s1)
    axs[1, 0].plot(x1_FPC2, y1_FPC2, linestyle='-', label='FPC2', color=color_fpc2_s1)
    axs[1, 0].set_ylim(global_y_FPC_min, global_y_FPC_max)  # Set y-limits
    axs[1, 0].set_xlabel('Time (s)')
    axs[1, 0].set_ylabel('Functional PC Values')
    axs[1, 0].legend()
    axs[1, 0].grid(False)

    # FPC's System 2
    axs[1, 1].plot(x2_FPC1, y2_FPC1, linestyle='-', label='FPC1', color=color_fpc1_s2)
    axs[1, 1].plot(x2_FPC2, y2_FPC2, linestyle='-', label='FPC2', color=color_fpc2_s2)
    axs[1, 1].set_ylim(global_y_FPC_min, global_y_FPC_max)  # Set y-limits
    axs[1, 1].set_xlabel('Time (s)')
    axs[1, 1].set_ylabel('Functional PC Values')
    axs[1, 1].legend()
    axs[1, 1].grid(False)


    # FPC1 System 1 versus FPC1 System 2
    fig = plt.figure(figsize=(7.3, 3))
    plt.plot(x1_FPC1, y1_FPC1, linestyle='-', label='FPC1 - S1')
    plt.plot(x2_FPC1, y2_FPC1, linestyle='-', label='FPC1 - S2')

    plt.legend()
    plt.grid(False)
    plt.xlabel('Time (s)')
    plt.ylabel('Functional PC1 Values')
    plt.ylim(global_y_FPC1_min, global_y_FPC1_max)
    plt.show()

    return pc_scores_s1, pc_scores_s2, fpca_s1.components_, fpca_s2.components_
