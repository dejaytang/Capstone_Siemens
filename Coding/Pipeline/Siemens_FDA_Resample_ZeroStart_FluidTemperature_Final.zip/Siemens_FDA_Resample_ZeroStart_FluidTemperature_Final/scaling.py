def align_to_zero(df):
    """
    Aligns each column of the DataFrame to its first value (zero index) by subtracting
    the first column from all subsequent columns.

    Parameters:
        df (DataFrame): The input DataFrame.

    Returns:
        DataFrame: DataFrame with each column aligned to its first value.
    """
    return df.iloc[:, 1:].sub(df.iloc[:, 1], axis=0)
