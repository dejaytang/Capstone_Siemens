import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
def Merge_data(windows, merge_data):
    """
    Merge the 'windows' dataframe with selected columns from the 'merge' dataframe,
    categorize 'AgeOfCardInDaysAtTimeOfTest' and 'AmbientTemperature' into bins,
    and return a random sample of the combined dataframe.

    Parameters:
    windows (DataFrame): The primary dataframe to merge.
    merge (DataFrame): The dataframe containing the additional columns to merge.

    Returns:
    DataFrame: A random sample of 500 rows from the merged dataframe.
    """

    # Merge the two dataframes on their indices
    window_combine = windows.merge(
        merge_data[["FluidType", "AgeOfCardInDaysAtTimeOfTest", "Fluid_Temperature_Filled"]],
        how="inner",
        left_index=True,
        right_index=True
    )

    # Categorize 'AgeOfCardInDaysAtTimeOfTest' into bins
    window_combine["CardAgeBin"] = pd.cut(
        window_combine["AgeOfCardInDaysAtTimeOfTest"],
        bins=[0, 9, 28, 56, 84, 112, 140, 168, 196, 224, 252],
        labels=['Below 9', '9-28', '28-56', '56-84', '84-112', '112-140', '140-168', '168-196', '196-224', '224-252']
    )

    # Categorize 'FluidType' into Blood and Aqueous
    window_combine['FluidTypeBin'] = np.where(window_combine['FluidType'].str.startswith('Eurotrol'), 'Aqueous', 'Blood')

    # Categorize 'Fluid_Temperature_Filled' into bins
    window_combine["FluidTempBin"] = pd.cut(
        window_combine["Fluid_Temperature_Filled"],
        bins=[-1, 20, 25, 100],
        labels=['Below 20', '20-25', 'Above 25']
    )
    return window_combine
